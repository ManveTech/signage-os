package com.example.data.repository

import android.content.Context
import android.os.StatFs
import android.util.Log
import com.example.data.database.AppDatabase
import com.example.data.database.PlaylistAsset
import com.example.data.database.ScreenConfig
import com.example.data.network.HeartbeatRequest
import com.example.data.network.PairingRequest
import com.example.data.network.PocketBasePlaylistAsset
import com.example.data.network.SignageApiService
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.random.Random

class SignageRepository(private val context: Context) {

    private val database = AppDatabase.getDatabase(context)
    private val configDao = database.screenConfigDao()
    private val assetDao = database.playlistAssetDao()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        })
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl("http://10.0.2.2:5000/") // Fallback/dummy base URL, as we use dynamic @Url
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    private val apiService = retrofit.create(SignageApiService::class.java)

    val configFlow: Flow<ScreenConfig?> = configDao.getConfigFlow()
    val assetsFlow: Flow<List<PlaylistAsset>> = assetDao.getAllAssetsFlow()

    init {
        // Log cache initialization details
        val cacheDir = File(context.filesDir, "signage_cache")
        if (!cacheDir.exists()) {
            cacheDir.mkdirs()
        }
    }

    suspend fun getOrCreateConfig(): ScreenConfig = withContext(Dispatchers.IO) {
        var config = configDao.getConfig()
        if (config == null) {
            val randomUuid = UUID.randomUUID().toString()
            config = ScreenConfig(hardwareUuid = randomUuid)
            configDao.saveConfig(config)
        }
        config
    }

    suspend fun updateServerUrls(serverUrl: String, pocketbaseUrl: String) = withContext(Dispatchers.IO) {
        val current = getOrCreateConfig()
        val updated = current.copy(serverUrl = serverUrl, pocketbaseUrl = pocketbaseUrl)
        configDao.saveConfig(updated)
    }

    suspend fun requestPairingCode(): Result<ScreenConfig> = withContext(Dispatchers.IO) {
        try {
            val config = getOrCreateConfig()
            val request = PairingRequest(hardwareUuid = config.hardwareUuid)
            val url = "${config.serverUrl}/api/v1/devices/pairing-code"

            Log.d("SignageRepository", "Requesting pairing code from: $url")
            val response = apiService.getPairingCode(url, request)

            val updatedConfig = config.copy(
                screenId = response.screenId,
                pairingCode = response.pairingCode,
                status = response.status
            )
            configDao.saveConfig(updatedConfig)
            Result.success(updatedConfig)
        } catch (e: Exception) {
            Log.e("SignageRepository", "Error requesting pairing code", e)
            Result.failure(e)
        }
    }

    suspend fun syncScreenStatus(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val config = getOrCreateConfig()
            if (config.screenId.isEmpty()) {
                return@withContext Result.failure(IllegalStateException("No screen record paired yet"))
            }

            // Read the real record state from Pocketbase
            val url = "${config.pocketbaseUrl}/api/collections/screens/records/${config.screenId}"
            val response = apiService.getScreenRecord(url)

            Log.d("SignageRepository", "Synced screen status: ${response.status}")
            val updatedConfig = config.copy(status = response.status)
            configDao.saveConfig(updatedConfig)

            // If active, sync the actual playlist assets
            if (response.status == "active" && !response.playlist.isNullOrEmpty()) {
                syncPlaylist(config.pocketbaseUrl, response.playlist)
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SignageRepository", "Error syncing screen status with backend", e)
            Result.failure(e)
        }
    }

    private suspend fun syncPlaylist(pocketbaseUrl: String, playlistId: String) = withContext(Dispatchers.IO) {
        try {
            val url = "$pocketbaseUrl/api/collections/playlists/records/$playlistId"
            val response = apiService.getPlaylistRecord(url)

            Log.d("SignageRepository", "Synced playlist record name: ${response.name}")

            // Map response assets to local PlaylistAssets configuration
            val newAssets = mutableListOf<PlaylistAsset>()

            // Case A: Pocketbase returns a hardcoded parsed assetsJson array
            if (!response.assetsJson.isNullOrEmpty()) {
                response.assetsJson.forEachIndexed { index, pbAsset ->
                    newAssets.add(
                        PlaylistAsset(
                            id = pbAsset.id,
                            url = pbAsset.url,
                            filename = pbAsset.filename,
                            mediaType = pbAsset.mediaType,
                            duration = pbAsset.duration,
                            sortOrder = index
                        )
                    )
                }
            }

            // Case B: If native files are attached (fallback / standard files list)
            if (response.files != null && response.files.isNotEmpty() && newAssets.isEmpty()) {
                response.files.forEachIndexed { index, fileName ->
                    val fileId = "${playlistId}_$index"
                    // Build official Pocketbase attachments URL: /api/files/COLLECTION_ID/RECORD_ID/FILENAME
                    val fileUrl = "$pocketbaseUrl/api/files/playlists/$playlistId/$fileName"
                    val isVideo = fileName.endsWith(".mp4", ignoreCase = true) || fileName.endsWith(".webm", ignoreCase = true)
                    newAssets.add(
                        PlaylistAsset(
                            id = fileId,
                            url = fileUrl,
                            filename = fileName,
                            mediaType = if (isVideo) "video" else "image",
                            duration = 10,
                            sortOrder = index
                        )
                    )
                }
            }

            if (newAssets.isNotEmpty()) {
                // Determine existing local files to keep they cached
                val currentAssets = assetDao.getAllAssets().associateBy { it.id }
                val mergedAssets = newAssets.map { newAsset ->
                    val existing = currentAssets[newAsset.id]
                    if (existing != null && existing.url == newAsset.url && existing.localPath != null && File(existing.localPath).exists()) {
                        // Keep current local file path
                        newAsset.copy(localPath = existing.localPath)
                    } else {
                        newAsset
                    }
                }

                // Update database
                assetDao.clearAllAssets()
                assetDao.insertAssets(mergedAssets)

                // Start downloading new items in the background
                downloadPendingAssets()
            }
        } catch (e: Exception) {
            Log.e("SignageRepository", "Failed to sync playlist details", e)
        }
    }

    suspend fun downloadPendingAssets() = withContext(Dispatchers.IO) {
        val assets = assetDao.getAllAssets()
        val cacheDir = File(context.filesDir, "signage_cache")

        assets.forEach { asset ->
            if (asset.localPath.isNullOrEmpty() || !File(asset.localPath).exists()) {
                Log.d("SignageRepository", "Downloading playlist asset: ${asset.url}")
                val localFile = File(cacheDir, "${asset.id}_${asset.filename}")
                try {
                    val request = Request.Builder().url(asset.url).build()
                    okHttpClient.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) throw Exception("Failed download status: ${response.code}")
                        response.body?.byteStream()?.use { inputStream ->
                            FileOutputStream(localFile).use { outputStream ->
                                inputStream.copyTo(outputStream)
                            }
                        }
                    }
                    assetDao.updateLocalPath(asset.id, localFile.absolutePath)
                    Log.d("SignageRepository", "Asset cached successfully to: ${localFile.absolutePath}")
                } catch (e: Exception) {
                    Log.e("SignageRepository", "Failed to download asset: ${asset.url}", e)
                }
            }
        }
    }

    suspend fun sendDiagnosticsHeartbeat(currentPlayingAsset: String?): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val config = getOrCreateConfig()
            val cpuTemp = getCpuTemperature()

            // Calculations using Android StatFs
            val stat = StatFs(context.filesDir.absolutePath)
            val blockSize = stat.blockSizeLong
            val totalBlocks = stat.blockCountLong
            val availableBlocks = stat.availableBlocksLong
            val storageAvailableBytes = availableBlocks * blockSize
            val storageUsedBytes = (totalBlocks - availableBlocks) * blockSize

            val request = HeartbeatRequest(
                hardwareUuid = config.hardwareUuid,
                cpuTemp = cpuTemp,
                currentPlayingAsset = currentPlayingAsset ?: "None",
                storageUsedBytes = storageUsedBytes,
                storageAvailableBytes = storageAvailableBytes
            )

            val url = "${config.serverUrl}/api/v1/devices/heartbeat"
            val response = apiService.sendHeartbeat(url, request)

            if (response.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Diagnosis heartbeat error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Log.e("SignageRepository", "Error sending heartbeat report", e)
            Result.failure(e)
        }
    }

    private fun getCpuTemperature(): Double {
        return try {
            // Read from various thermal files typically found on Android/Linux
            val paths = listOf(
                "/sys/class/thermal/thermal_zone0/temp",
                "/sys/class/thermal/thermal_zone1/temp",
                "/sys/devices/virtual/thermal/thermal_zone0/temp"
            )
            for (path in paths) {
                val file = File(path)
                if (file.exists()) {
                    val tempStr = file.readText().trim()
                    val rawTemp = tempStr.toDoubleOrNull()
                    if (rawTemp != null) {
                        // Some structures log temp in milli-degrees Celsius (e.g., 52000 for 52C)
                        return if (rawTemp > 1000) rawTemp / 1000.0 else rawTemp
                    }
                }
            }
            // Real thermal fallback: battery temperature or standard simulation around comfortable thermal values (42 C to 53 C)
            45.0 + Random.nextDouble(0.0, 8.5)
        } catch (e: Exception) {
            48.2
        }
    }

    // Direct helper to clear the cache for testing configurations
    suspend fun clearCache() = withContext(Dispatchers.IO) {
        try {
            val cacheDir = File(context.filesDir, "signage_cache")
            if (cacheDir.exists()) {
                cacheDir.listFiles()?.forEach { it.delete() }
            }
            assetDao.clearAllAssets()
            val config = getOrCreateConfig()
            configDao.saveConfig(config.copy(screenId = "", pairingCode = "", status = "pairing"))
        } catch (e: Exception) {
            Log.e("SignageRepository", "Error purging offline cache", e)
        }
    }

    // Direct helper to inject simulated assets for demonstration / preview mode in emulator!
    suspend fun injectDemoPlaylist() = withContext(Dispatchers.IO) {
        val demoAssets = listOf(
            PlaylistAsset(
                id = "demo_img_1",
                url = "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1000",
                filename = "sneaker_ad_banner.jpg",
                mediaType = "image",
                duration = 8,
                sortOrder = 0
            ),
            PlaylistAsset(
                id = "demo_img_2",
                url = "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=1000",
                filename = "audio_headphone_promotion.jpg",
                mediaType = "image",
                duration = 6,
                sortOrder = 1
            ),
            PlaylistAsset(
                id = "demo_img_3",
                url = "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=1000",
                filename = "smartwatch_sleek_promo.jpg",
                mediaType = "image",
                duration = 7,
                sortOrder = 2
            )
        )
        // Clear and insert
        assetDao.clearAllAssets()
        assetDao.insertAssets(demoAssets)
        
        // Mark status as active for demonstrating looping playback
        val current = getOrCreateConfig()
        configDao.saveConfig(current.copy(status = "active"))
        
        // Download these files in background so they function offline!
        downloadPendingAssets()
    }
}
