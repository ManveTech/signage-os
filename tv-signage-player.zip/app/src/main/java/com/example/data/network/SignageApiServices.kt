package com.example.data.network

import com.squareup.moshi.JsonClass
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Url

@JsonClass(generateAdapter = true)
data class PairingRequest(
    val hardwareUuid: String
)

@JsonClass(generateAdapter = true)
data class PairingResponse(
    val screenId: String,
    val pairingCode: String,
    val status: String
)

@JsonClass(generateAdapter = true)
data class HeartbeatRequest(
    val hardwareUuid: String,
    val cpuTemp: Double,
    val currentPlayingAsset: String?,
    val storageUsedBytes: Long,
    val storageAvailableBytes: Long
)

@JsonClass(generateAdapter = true)
data class PocketBaseScreenResponse(
    val id: String,
    val status: String,
    val playlist: String? = null,
    val name: String? = null
)

@JsonClass(generateAdapter = true)
data class PocketBasePlaylistAsset(
    val id: String,
    val url: String,
    val filename: String,
    val mediaType: String, // "image" or "video"
    val duration: Int = 10
)

@JsonClass(generateAdapter = true)
data class PocketBasePlaylistResponse(
    val id: String,
    val name: String? = null,
    val description: String? = null,
    // Pocketbase might store assets as an array of JSON objects or individual records
    val assetsJson: List<PocketBasePlaylistAsset>? = null,
    // File names managed by PB's native files storage
    val files: List<String>? = null
)

interface SignageApiService {
    @POST
    suspend fun getPairingCode(
        @Url url: String,
        @Body request: PairingRequest
    ): PairingResponse

    @POST
    suspend fun sendHeartbeat(
        @Url url: String,
        @Body request: HeartbeatRequest
    ): Response<Unit>

    @GET
    suspend fun getScreenRecord(
        @Url url: String
    ): PocketBaseScreenResponse

    @GET
    suspend fun getPlaylistRecord(
        @Url url: String
    ): PocketBasePlaylistResponse
}
