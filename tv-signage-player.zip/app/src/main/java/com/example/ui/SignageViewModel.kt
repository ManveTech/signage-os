package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.PlaylistAsset
import com.example.data.database.ScreenConfig
import com.example.data.repository.SignageRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class SignageUiState(
    val hardwareUuid: String = "",
    val screenId: String = "",
    val pairingCode: String = "",
    val status: String = "pairing", // "pairing", "active", "suspended"
    val screenName: String = "Digital Signage",
    val serverUrl: String = "http://10.0.2.2:5000",
    val pocketbaseUrl: String = "http://10.0.2.2:8090",
    val lastSyncedAt: Long = 0L,
    val playlist: List<PlaylistAsset> = emptyList(),
    val currentAssetIndex: Int = 0,
    val isSyncing: Boolean = false,
    val showAdminOverlay: Boolean = false,
    val statusMessage: String = "Initializing system...",
    val errorMessage: String? = null
)

class SignageViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SignageRepository(application)

    private val _uiState = MutableStateFlow(SignageUiState())
    val uiState: StateFlow<SignageUiState> = _uiState.asStateFlow()

    private var syncJob: Job? = null
    private var heartbeatJob: Job? = null
    private var assetRotationJob: Job? = null

    init {
        // Collect database config state
        viewModelScope.launch {
            repository.configFlow.collectLatest { config ->
                if (config != null) {
                    _uiState.update {
                        it.copy(
                            hardwareUuid = config.hardwareUuid,
                            screenId = config.screenId,
                            pairingCode = config.pairingCode,
                            status = config.status,
                            screenName = config.screenName,
                            serverUrl = config.serverUrl,
                            pocketbaseUrl = config.pocketbaseUrl,
                            lastSyncedAt = config.lastSyncedAt
                        )
                    }
                    // Start or update asset rotational loop based on playlist changes
                    restartAssetRotation()
                } else {
                    // Pre-create configuration
                    repository.getOrCreateConfig()
                }
            }
        }

        // Collect database playlist state
        viewModelScope.launch {
            repository.assetsFlow.collectLatest { assets ->
                _uiState.update { it.copy(playlist = assets) }
                restartAssetRotation()
            }
        }

        // Start dynamic sync and diagnostics background services
        startSyncEngine()
        startDiagnosticsHeartbeatEngine()

        // Generate initial pairing code request if setup is needed
        viewModelScope.launch {
            val current = repository.getOrCreateConfig()
            if (current.pairingCode.isEmpty()) {
                requestPairingCode()
            }
        }
    }

    fun requestPairingCode() {
        viewModelScope.launch {
            _uiState.update { it.copy(isSyncing = true, statusMessage = "Generating pairing code...") }
            val result = repository.requestPairingCode()
            _uiState.update { state ->
                if (result.isSuccess) {
                    val config = result.getOrNull()
                    state.copy(
                        isSyncing = false,
                        pairingCode = config?.pairingCode ?: "",
                        screenId = config?.screenId ?: "",
                        statusMessage = "Awaiting pairing from Bluestar CMS..."
                    )
                } else {
                    state.copy(
                        isSyncing = false,
                        errorMessage = "Pairing failed: " + result.exceptionOrNull()?.message,
                        statusMessage = "Network retry active..."
                    )
                }
            }
        }
    }

    private fun startSyncEngine() {
        syncJob?.cancel()
        syncJob = viewModelScope.launch {
            while (isActive) {
                try {
                    val config = repository.getOrCreateConfig()
                    if (config.screenId.isNotEmpty()) {
                        repository.syncScreenStatus()
                    } else if (config.pairingCode.isEmpty()) {
                        repository.requestPairingCode()
                    }
                } catch (e: Exception) {
                    Log.e("SignageViewModel", "Background sync failure", e)
                }
                // Poll screen stats and pairing actions every 7.5 seconds
                delay(7500)
            }
        }
    }

    private fun startDiagnosticsHeartbeatEngine() {
        heartbeatJob?.cancel()
        heartbeatJob = viewModelScope.launch {
            while (isActive) {
                try {
                    val state = _uiState.value
                    if (state.status == "active") {
                        val currentAsset = state.playlist.getOrNull(state.currentAssetIndex)
                        repository.sendDiagnosticsHeartbeat(currentAsset?.filename)
                    }
                } catch (e: Exception) {
                    Log.e("SignageViewModel", "Heartbeat broadcast failed", e)
                }
                // Broadcase diagnostic heartbeats once a minute
                delay(60000)
            }
        }
    }

    private fun restartAssetRotation() {
        assetRotationJob?.cancel()
        val playlist = _uiState.value.playlist
        if (playlist.isEmpty() || _uiState.value.status != "active") {
            return
        }

        assetRotationJob = viewModelScope.launch {
            while (isActive) {
                val currentIndex = _uiState.value.currentAssetIndex
                val currentAsset = playlist.getOrNull(currentIndex) ?: break
                val durationMs = (currentAsset.duration * 1000L).coerceAtLeast(3000L) // Min 3 seconds

                delay(durationMs)

                // Advance to the next playlist asset looping
                _uiState.update {
                    val nextIndex = if (playlist.isNotEmpty()) (it.currentAssetIndex + 1) % playlist.size else 0
                    it.copy(currentAssetIndex = nextIndex)
                }
            }
        }
    }

    fun saveServerUrls(serverUrl: String, pocketbaseUrl: String) {
        viewModelScope.launch {
            repository.updateServerUrls(serverUrl, pocketbaseUrl)
            hideAdminOverlay()
            // Reset state and re-request code
            requestPairingCode()
        }
    }

    fun purgeCacheAndReset() {
        viewModelScope.launch {
            _uiState.update { it.copy(isSyncing = true, statusMessage = "Purging offline database..." ) }
            repository.clearCache()
            _uiState.update {
                it.copy(
                    isSyncing = false,
                    currentAssetIndex = 0,
                    statusMessage = "Cleared. Ready to pair."
                )
            }
            requestPairingCode()
        }
    }

    fun toggleAdminOverlay() {
        _uiState.update { it.copy(showAdminOverlay = !it.showAdminOverlay) }
    }

    fun hideAdminOverlay() {
        _uiState.update { it.copy(showAdminOverlay = false) }
    }

    fun testWithSimulatedDemo() {
        viewModelScope.launch {
            _uiState.update { it.copy(isSyncing = true, statusMessage = "Injecting sample promotional files..." ) }
            repository.injectDemoPlaylist()
            _uiState.update {
                it.copy(
                    isSyncing = false,
                    status = "active",
                    statusMessage = "Demo Active"
                )
            }
            restartAssetRotation()
        }
    }
    
    fun simulateLicenceSuspended() {
        viewModelScope.launch {
            _uiState.update { it.copy(status = "suspended", statusMessage = "License suspended simulation" ) }
        }
    }
}
